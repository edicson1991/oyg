export const config = {
    apiUrlCities: 'https://raw.githubusercontent.com/juvillegc/cities/main'
};